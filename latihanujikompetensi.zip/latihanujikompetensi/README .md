# Web untuk pemesanan Laundry
Web ini digunakan untuk memesan jasa laundry per cabang di setiap domisili

[![N|Solid](https://cldup.com/dTxpPi9lDf.thumb.png)](https://nodesource.com/products/nsolid)

[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)

[![Telegram](https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://web.telegram.org/k/)


## Features Web Penjumlahan luas bangun datar
- Cabang Laundry
- Menampilkan Nama Pelanggan, Nomor HP, Jumlah Kg, Tagihan awal, diskon (jika ada) dan tagihan akhir pada output
- Ada fitur diskon secara otomatis apabila pemesanan lebih dari 100 pcs
- ✨Magic ✨


## Web dibangun menggunakan
- Xampp
- Visual Studio Code

## membuka file web luas bangun datar
- Buka XAMPP panel dan aktifkan server Apache dan SQL
- Buka Folder dengan link http://localhost/vsga10/tugas5_Ira%20Ayu%20Riyanto/

## Struktur

📦latihan
 ┣ 📂css
 ┃ ┣ 📜bootstrap-grid.css
 ┃ ┣ 📜bootstrap-grid.css.map
 ┃ ┣ 📜bootstrap-grid.min.css
 ┃ ┣ 📜bootstrap-grid.min.css.map
 ┃ ┣ 📜bootstrap-grid.rtl.css
 ┃ ┣ 📜bootstrap-grid.rtl.css.map
 ┃ ┣ 📜bootstrap-grid.rtl.min.css
 ┃ ┣ 📜bootstrap-grid.rtl.min.css.map
 ┃ ┣ 📜bootstrap-reboot.css
 ┃ ┣ 📜bootstrap-reboot.css.map
 ┃ ┣ 📜bootstrap-reboot.min.css
 ┃ ┣ 📜bootstrap-reboot.min.css.map
 ┃ ┣ 📜bootstrap-reboot.rtl.css
 ┃ ┣ 📜bootstrap-reboot.rtl.css.map
 ┃ ┣ 📜bootstrap-reboot.rtl.min.css
 ┃ ┣ 📜bootstrap-reboot.rtl.min.css.map
 ┃ ┣ 📜bootstrap-utilities.css
 ┃ ┣ 📜bootstrap-utilities.css.map
 ┃ ┣ 📜bootstrap-utilities.min.css
 ┃ ┣ 📜bootstrap-utilities.min.css.map
 ┃ ┣ 📜bootstrap-utilities.rtl.css
 ┃ ┣ 📜bootstrap-utilities.rtl.css.map
 ┃ ┣ 📜bootstrap-utilities.rtl.min.css
 ┃ ┣ 📜bootstrap-utilities.rtl.min.css.map
 ┃ ┣ 📜bootstrap.css
 ┃ ┣ 📜bootstrap.css.map
 ┃ ┣ 📜bootstrap.min.css
 ┃ ┣ 📜bootstrap.min.css.map
 ┃ ┣ 📜bootstrap.rtl.css
 ┃ ┣ 📜bootstrap.rtl.css.map
 ┃ ┣ 📜bootstrap.rtl.min.css
 ┃ ┗ 📜bootstrap.rtl.min.css.map
 ┣ 📂js
 ┃ ┣ 📜bootstrap.bundle.js
 ┃ ┣ 📜bootstrap.bundle.js.map
 ┃ ┣ 📜bootstrap.bundle.min.js
 ┃ ┣ 📜bootstrap.bundle.min.js.map
 ┃ ┣ 📜bootstrap.esm.js
 ┃ ┣ 📜bootstrap.esm.js.map
 ┃ ┣ 📜bootstrap.esm.min.js
 ┃ ┣ 📜bootstrap.esm.min.js.map
 ┃ ┣ 📜bootstrap.js
 ┃ ┣ 📜bootstrap.js.map
 ┃ ┣ 📜bootstrap.min.js
 ┃ ┗ 📜bootstrap.min.js.map
 ┣ 📜baju.php
 ┣ 📜laundry.jpg
 ┣ 📜laundry.json
 ┗ 📜pesanan.php
## Contact

- Gmail (ayuira42@gmail.com)
- Github (https://github.com/iraayu)