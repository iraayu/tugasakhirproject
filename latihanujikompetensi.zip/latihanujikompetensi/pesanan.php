<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel ="stylesheet">
    
	<title>Form Laundry</title>
</head>
<body>

	<h2>Form Pesanan Laundry</h2>

	<img src="https://media.istockphoto.com/vectors/laundry-logo-for-your-business-isolated-on-white-background-vector-id1056565126?k=6&m=1056565126&s=612x612&w=0&h=GM78FzscGXPJwT3IH2ZgrvN0NX4DpfeFDQb-3laEUWw=" width="150" height="200">

	<form method="post">
		<table>
			<tr>
				<td>Cabang</td>
				<td> 
				<select name="pilih">
						<!-- <option value="" disabled selected>Pilih Cabang</option> -->
				        <option value="bekasi">Bekasi</option>
				        <option value="depok">Depok</option>
				        <option value="bogor">Bogor</option>
					
				</select> </td>
			</tr>
			<tr>
				<td>Nama Pelanggan</td>
				<td> <input type="text" name="nama" required> </td>
			</tr>
			<tr>
				<td>Nomor HP</td>
				<td> <input type="text" name="hp" required> </td>
			</tr>
			<tr>
				<td>Jumlah Dalam Kg</td>
				<td> <input type="text" name="jumlah" required> </td>
			</tr>

			<tr>
				<td>
					<button type="submit" class="btn btn-primary" name="klik">Kirim</button>

				</td>
			</tr>
		</table>
	</form>

	<hr>

		<?php 

$nama = $_POST['nama'];
$hp      = $_POST['hp'];
$jumblah  = $_POST['jumlah'];
$tagihan = ($jumblah*50000);
$diskon  = ($tagihan* 5/100);
$akhir = ($tagihan-$diskon);
$pilih   = array("bekasi", "depok", "bogor");
   
array_multisort($pilih, SORT_ASC);

if (isset($_POST['klik'])) {
	if (!empty($_POST['pilih'])) {
		$pilih = $_POST['pilih'];
		switch ($pilih) {
			case 'bekasi':
				echo "<br>";
				echo "cabang " .$pilih;
				echo "<br>";
				echo "Nama Pelanggan : " .$nama;
				echo "<br>";
				echo "Nomor HP : " .$hp;
				echo "<br>";
				echo "Jumlah Pesanan Baju : " .$jumblah;
				echo "<br>";
				echo "Tagihan awal: " .$tagihan;
				echo "<br>";
				echo "Diskon: " .$diskon;
				echo "<br>";
				echo "Tagihan akhir: " .$akhir;
				echo "<br>";
				break;

				case 'depok':
				echo "<br>";
				echo "cabang " .$pilih;
				echo "<br>";
				echo "Nama Pelanggan : " .$nama;
				echo "<br>";
				echo "Nomor HP : " .$hp;
				echo "<br>";
				echo "Jumlah Pesanan Baju : " .$jumblah;
				echo "<br>";
				echo "Tagihan awal: " .$tagihan;
				echo "<br>";
				echo "Diskon: " .$diskon;
				echo "<br>";
				echo "Tagihan akhir: " .$akhir;
				echo "<br>";
				break;

				case 'bogor':
				echo "<br>";
				echo "cabang " .$pilih;
				echo "<br>";
				echo "Nama Pelanggan : " .$nama;
				echo "<br>";
				echo "Nomor HP : " .$hp;
				echo "<br>";
				echo "Jumlah Pesanan Baju : " .$jumblah;
				echo "<br>";
				echo "Tagihan awal: " .$tagihan;
				echo "<br>";
				echo "Diskon: " .$diskon;
				echo "<br>";
				echo "Tagihan akhir: " .$akhir;
				echo "<br>";
					break;
			  
			default:
				echo "nothing";
				break;
		}
	}


} 

// File json yang akan dibaca
$file = "laundry.json";

// Mendapatkan file json
$isi = file_get_contents($file);

// Mendecode anggota.json
$data = json_decode($isi, true);

// Data array baru
$data[] = array (

'cabang' => "$pilih",
'nama' => "$nama",
'nomor' => "$hp",
'jumlah' => "$jumblah",
'awal' => "$tagihan",
'diskon' => "$diskon",
'akhir' => "$akhir",


);


$konten = json_encode($data, JSON_PRETTY_PRINT);

//menyimpan konten di file
file_put_contents($file, $konten);

//menampilkan data

foreach ($data as $key => $value)
{

echo "<br>";
echo "cabang " .$value['cabang']. '<br>';
echo "Nama Pelanggan: " .$value['nama']. '<br>';
echo "Nomor HP: " .$value['nomor'] .'<br>';
echo "Jumlah Pesanan Baju: " .$value['jumlah']. '<br>';
echo "Tagihan Awal: " .$value['awal'] .'<br>';
echo "Diskon: " .$value['diskon'] .'<br>';
echo "Tagihan akhir: " .$value['akhir']. '<br>';
echo "<br>";
}

	 ?>




</body>
</html>